"""
elasticmetrics
~~~~~~~~~~~~~~
Collect performance metrics from ElasticSearch.

:license: MIT Licencse. See LICENSE file for details
"""

__version__ = "0.1.1"
