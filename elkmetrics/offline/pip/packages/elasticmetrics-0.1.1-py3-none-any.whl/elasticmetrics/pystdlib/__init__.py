"""
elasticmetrics.pystdlib
~~~~~~~~~~~~~~~~~~~~~~~
Proxy to Python standard library, abstracing 2/3 differences,
to keep try/imports in one place.
"""
