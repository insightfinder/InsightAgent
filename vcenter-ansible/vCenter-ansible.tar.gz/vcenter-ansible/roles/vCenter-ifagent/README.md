Ansible Role: vCenter-ifagent
=========

Install vCenter agent on CentOS/RedHat.

Requirements
------------

None.

Role Variables
--------------

None.

Dependencies
------------

None.
