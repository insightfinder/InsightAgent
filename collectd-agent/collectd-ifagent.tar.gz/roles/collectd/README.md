Ansible Role: collectd
=========

Install collectd on CentOS/RedHat 7.

Requirements
------------

None.

Role Variables
--------------

None.

Dependencies
------------

None.
