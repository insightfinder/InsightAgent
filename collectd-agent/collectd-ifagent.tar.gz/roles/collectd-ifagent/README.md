Ansible Role: collectd-ifagent
=========

Install collectd agent on CentOS/RedHat 7.

Requirements
------------

None.

Role Variables
--------------

None.

Dependencies
------------

None.
