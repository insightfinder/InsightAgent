fastavro.utils
==============

.. autofunction:: fastavro.utils.generate_one
.. autofunction:: fastavro.utils.generate_many
.. autofunction:: fastavro.utils.anonymize_schema
