import os
import sys
import time
import pytz
import logging
import configparser
from datetime import date, datetime
from optparse import OptionParser

import requests


def get_anomaly_data():
    # Format Request
    host = edge_vars['host']

    ## TODO: Add configurable time window.  Currently hardcoded to the current day

    today = datetime.strptime(date.today().strftime("%Y-%m-%d"), "%Y-%m-%d").replace(tzinfo=edge_vars['timezone'])

    start_time = int(today.timestamp()) * 1000

    end_time = int(datetime.now(edge_vars['timezone']).timestamp()) * 1000

    data = {'projectName': edge_vars['project_name'], 'transferToProjectName': main_vars['project_name'],
            'transferToCustomerName': main_vars['user_name'],
            'startTime': start_time, 'endTime': end_time, 'licenseKey': edge_vars['license_key'],
            'userName': edge_vars['user_name']}

    url = host + '/api/v2/projectanomalytransfer'

    logging.info(f"{url} {data}")

    # Send Request
    resp = requests.get(url, params=data, verify=False)
    count = 0
    logging.info(f"HTTP Response Code: {resp.status_code}")
    while resp.status_code != 200 and count < edge_vars['retry']:
        time.sleep(60)
        resp = requests.post(url, data=data, verify=False)
        logging.info(f"HTTP Response Code: {resp.status_code}")
        count += 1

    result = {}
    try:
        result = resp.json()
    except Exception as e:
        logging.WARNING(e)

    logging.debug(f"{result}")
    return result


def send_anomaly_data(data):
    host = main_vars['host']
    url = host + '/api/v2/projectanomalyreceive'
    auth = {'licenseKey': main_vars['license_key'], 'userName': main_vars['user_name']}
    logging.info(f"{url} {auth} {data}")
    # do not send if only testing
    if cli_config_vars['testing']:
        return

    resp = requests.post(url, params=auth, json=data, verify=False)
    count = 0
    logging.info(f"HTTP Response Code: {resp.status_code}")
    while resp.status_code != 200 and count < main_vars['retry']:
        time.sleep(60)
        resp = requests.post(url, params=auth, json=data, verify=False)
        logging.info(f"HTTP Response Code: {resp.status_code}")
        count += 1
    return resp.status_code


def get_cli_config_vars():
    """ get CLI options. use of these options should be rare """
    usage = 'Usage: %prog [options]'
    parser = OptionParser(usage=usage)

    parser.add_option('-c', '--config', action='store', dest='config', default=abs_path_from_cur('config.ini'),
                      help='Path to the config file to use. Defaults to {}'.format(abs_path_from_cur('config.ini')))
    parser.add_option('-q', '--quiet', action='store_true', dest='quiet', default=False,
                      help='Only display warning and error log messages')
    parser.add_option('-v', '--verbose', action='store_true', dest='verbose', default=False,
                      help='Enable verbose logging')
    parser.add_option('-t', '--testing', action='store_true', dest='testing', default=False,
                      help='Set to testing mode (do not send data).' +
                           ' Automatically turns on verbose logging')
    (options, args) = parser.parse_args()

    config_vars = {
        'config': options.config if os.path.isfile(options.config) else abs_path_from_cur('config.ini'),
        'threads': 1,
        'testing': False,
        'log_level': logging.INFO
    }

    if options.testing:
        config_vars['testing'] = True

    if options.verbose:
        config_vars['log_level'] = logging.DEBUG
    elif options.quiet:
        config_vars['log_level'] = logging.WARNING

    return config_vars


def config_ini_path():
    return abs_path_from_cur(cli_config_vars['config'])


def abs_path_from_cur(filename=''):
    return os.path.abspath(os.path.join(__file__, os.pardir, filename))


def get_config_vars():
    """ Read and parse config.ini """
    config_ini = config_ini_path()
    if os.path.exists(config_ini):
        config_parser = configparser.ConfigParser()
        config_parser.read(config_ini)

        try:
            # Edge Node Parameters
            edge_url = config_parser.get('edge', 'url')
            edge_retry = config_parser.get('edge', 'retry') or 3
            edge_user = config_parser.get('edge', 'user_name')
            edge_license = config_parser.get('edge', 'license_key')
            edge_project_name = config_parser.get('edge', 'project_name')
            edge_project_type = config_parser.get('edge', 'project_type').upper()
            edge_timezone = config_parser.get('edge', 'timezone') or 'UTC'
            edge_http_proxy = config_parser.get('edge', 'http_proxy')
            edge_https_proxy = config_parser.get('edge', 'https_proxy')

            # Main IF Parameters
            main_url = config_parser.get('main', 'url')
            main_retry = config_parser.get('main', 'retry') or 3
            main_user = config_parser.get('main', 'user_name')
            main_license = config_parser.get('main', 'license_key')
            main_project_name = config_parser.get('main', 'project_name')
            main_http_proxy = config_parser.get('main', 'http_proxy')
            main_https_proxy = config_parser.get('main', 'https_proxy')

        except configparser.NoOptionError as cp_noe:
            logging.error(cp_noe)
            config_error()

        # Placeholders for Metric as Metric is not configured
        if edge_project_type not in {
            # 'METRIC',
            # 'METRICREPLAY',
            'LOG',
            'LOGREPLAY',
            'INCIDENT',
            'INCIDENTREPLAY',
            'ALERT',
            'ALERTREPLAY',
            'DEPLOYMENT',
            'DEPLOYMENTREPLAY'
        }:
            config_error('project_type')

        if edge_timezone:
            if edge_timezone not in pytz.all_timezones:
                config_error('timezone')
            else:
                edge_timezone = pytz.timezone(edge_timezone)

        # set edge proxies
        edge_proxies = dict()
        if len(edge_http_proxy) > 0:
            edge_proxies['http'] = edge_http_proxy
        if len(edge_https_proxy) > 0:
            edge_proxies['https'] = edge_https_proxy

        # set main proxies
        main_proxies = dict()
        if len(main_http_proxy) > 0:
            main_proxies['http'] = main_http_proxy
        if len(main_https_proxy) > 0:
            main_proxies['https'] = main_https_proxy

        edge = {
            'user_name': edge_user,
            'license_key': edge_license,
            'project_name': edge_project_name,
            'project_type': edge_project_type,
            'timezone': edge_timezone,
            'retry': edge_retry,
            'host': edge_url,
            'proxies': edge_proxies
        }

        main = {
            'user_name': main_user,
            'license_key': main_license,
            'project_name': main_project_name,
            'retry': main_retry,
            'host': main_url,
            'proxies': main_proxies
        }

        return (edge, main)

    else:
        config_error_no_config()


def config_error_no_config():
    logging.error('No config file found. Exiting...')
    sys.exit(1)


def config_error(setting=''):
    info = ' ({})'.format(setting) if setting else ''
    logging.error('Agent not correctly configured{}. Check config file.'.format(
        info))
    sys.exit(1)


if __name__ == "__main__":
    cli_config_vars = get_cli_config_vars()

    logging.basicConfig(level=cli_config_vars['log_level'],
                        format=('%(asctime)-15s '
                                '%(filename)s: '
                                '%(levelname)s: '
                                '%(funcName)s(): '
                                '%(lineno)d:\t'
                                '%(message)s')
                        )

    logging.debug(cli_config_vars)

    (edge_vars, main_vars) = get_config_vars()

    edge_data = get_anomaly_data()
    send_anomaly_data(edge_data)
